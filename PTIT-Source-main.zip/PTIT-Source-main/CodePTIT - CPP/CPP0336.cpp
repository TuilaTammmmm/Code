// https://code.ptit.edu.vn/student/question/CPP0336
// XÂU CON NHỎ NHẤT - 1

#include <bits/stdc++.h>
using namespace std;

void TestCase()
{
    string s, t;
    cin >> s >> t;
    int dd[26] = {0};
    
    queue<int> q;


}

int main()
{
    int T;
    cin >> T;
    while (T--) {
        TestCase();
    }
    return 0;
}