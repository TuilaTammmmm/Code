#include <stdio.h>

int main()
{
    float c;
    scanf("%f", &c);
    printf("%.2f", c * 9 / 5 + 32);
    return 0;
}