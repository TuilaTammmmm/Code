#include <stdio.h>

int main()
{
    long long n;
    scanf("%lld", &n);
    printf("%lld", n * 2);
    return 0;
}