#include <stdio.h>
#include <string.h>

int main()
{
    char s[105];
    while (scanf("%s", s) != -1)
        puts(s);
    return 0;
}