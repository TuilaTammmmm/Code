// https://code.ptit.edu.vn/student/question/CHELLO
// Hello World

#include <iostream>
using namespace std;

int main() {
    cout << "Hello PTIT.";
    return 0;
}